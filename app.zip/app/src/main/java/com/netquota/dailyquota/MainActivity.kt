package com.netquota.dailyquota

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF14253D)
private val Muted = Color(0xFF718096)
private val Canvas = Color(0xFFF4F7F8)
private val Teal = Color(0xFF087F72)
private val TealPale = Color(0xFFE3F4F0)
private val Border = Color(0xFFE3E9ED)
private val Amber = Color(0xFF9A5B06)
private val AmberPale = Color(0xFFFFF3D9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            QuotaApp()
        }
    }
}

@Composable
private fun QuotaApp() {
    val colors = lightColorScheme(
        primary = Teal,
        onPrimary = Color.White,
        background = Canvas,
        onBackground = Ink,
        surface = Color.White,
        onSurface = Ink,
        secondary = Amber,
        outline = Border,
    )

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = colors) {
            QuotaHome()
        }
    }
}

@Composable
private fun QuotaHome() {
    var quotaText by rememberSaveable { mutableStateOf("500") }
    var savedQuotaMb by rememberSaveable { mutableStateOf(500) }
    var savedMessage by rememberSaveable { mutableStateOf("") }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Canvas,
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, top = 16.dp, end = 20.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item { Header() }
            item { LocalScopeNotice() }
            item { UsageCard(quotaMb = savedQuotaMb) }
            item {
                QuotaEditor(
                    value = quotaText,
                    message = savedMessage,
                    onValueChange = { quotaText = it.filter(Char::isDigit) },
                    onSave = {
                        val nextValue = quotaText.toIntOrNull()
                        if (nextValue != null && nextValue > 0) {
                            savedQuotaMb = nextValue
                            savedMessage = "تم تحديث قيمة العرض لهذه الجلسة فقط"
                        } else {
                            savedMessage = "أدخل رقمًا أكبر من صفر"
                        }
                    },
                )
            }
            item { NextStageCard() }
            item { PrototypeFootnote() }
        }
    }
}

@Composable
private fun Header() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(
                text = "حصة الشبكة اليومية",
                color = Ink,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = "إدارة استخدام البيانات على جهازك",
                color = Muted,
                fontSize = 13.sp,
            )
        }
        Surface(
            shape = CircleShape,
            color = TealPale,
            modifier = Modifier.size(48.dp),
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(text = "و", color = Teal, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun LocalScopeNotice() {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Border),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.Top,
        ) {
            Surface(shape = CircleShape, color = TealPale, modifier = Modifier.size(28.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Text("✓", color = Teal, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("التحكم على هذا الهاتف فقط", color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "يجب تثبيت التطبيق على كل هاتف تريد تطبيق الحصة عليه.",
                    color = Muted,
                    fontSize = 12.sp,
                    lineHeight = 18.sp,
                )
            }
        }
    }
}

@Composable
private fun UsageCard(quotaMb: Int) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Ink),
        shape = RoundedCornerShape(24.dp),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("استهلاك اليوم", color = Color(0xFFC3D0DE), fontSize = 13.sp)
                    Text("لم يبدأ القياس بعد", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                }
                Surface(shape = RoundedCornerShape(50), color = Color(0xFF29405A)) {
                    Text(
                        text = "غير نشط",
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        color = Color(0xFFDCE7F0),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }

            LinearProgressIndicator(
                progress = 0f,
                modifier = Modifier.fillMaxWidth().height(8.dp),
                color = Color(0xFF5CD2B5),
                trackColor = Color(0xFF344A62),
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom,
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("المستهلك", color = Color(0xFFC3D0DE), fontSize = 12.sp)
                    Text("— MB", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.Start, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("الحصة اليومية", color = Color(0xFFC3D0DE), fontSize = 12.sp)
                    Text("$quotaMb MB", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                }
            }

            Text(
                text = "بيانات تجريبية — لا يوجد عدّ فعلي في هذه المرحلة",
                color = Color(0xFFB7C7D6),
                fontSize = 11.sp,
            )
        }
    }
}

@Composable
private fun QuotaEditor(
    value: String,
    message: String,
    onValueChange: (String) -> Unit,
    onSave: () -> Unit,
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(22.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Border),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("الحصة اليومية", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text("حدّد كمية البيانات المسموحة لهذا الهاتف بالميجابايت.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    label = { Text("الحد بالميجابايت") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    shape = RoundedCornerShape(14.dp),
                )
                Text("MB", color = Muted, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }

            Button(
                onClick = onSave,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(15.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Teal),
            ) {
                Text("حفظ حد العرض", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }

            if (message.isNotBlank()) {
                Text(message, color = Teal, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun NextStageCard() {
    Card(
        colors = CardDefaults.cardColors(containerColor = AmberPale),
        shape = RoundedCornerShape(20.dp),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(17.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text("المرحلة التالية", color = Amber, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(
                "إضافة عدّاد استهلاك الهاتف. بعد ذلك نعمل على التنبيهات ثم خدمة VPN والإيقاف.",
                color = Color(0xFF6D5428),
                fontSize = 12.sp,
                lineHeight = 18.sp,
            )
        }
    }
}

@Composable
private fun PrototypeFootnote() {
    Spacer(modifier = Modifier.height(2.dp))
    Text(
        text = "هذه واجهة أولية فقط: قيمة الحصة مؤقتة لهذه الجلسة، والقياس والحظر والإشعارات غير مفعّلة بعد.",
        modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
        color = Muted,
        fontSize = 11.sp,
        lineHeight = 17.sp,
        textAlign = TextAlign.Center,
    )
}
